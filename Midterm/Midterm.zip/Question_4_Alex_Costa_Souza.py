# Q4 - Sphere calculations
radius = float(input("Enter the radius of the sphere: "))

diameter = radius * 2
circumference = 2 * 3.14 * radius
surface_area = 4 * 3.14 * radius * radius
volume = (4/3) * 3.14 * radius ** 3

print("Sphere Diameter:", diameter)
print("Sphere Circumference:", circumference)
print("Sphere Surface Area:", surface_area)
print("Sphere Volume:", volume)

# Q3 - Print numbers from 1 to 50 using while loop
i = 1
while i <= 50:
    print(i)
    i += 1

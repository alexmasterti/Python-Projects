# Q5 - Print letters of the input string in the same line
word = input('Enter a word: ')

for letter in word:
    print(letter, end=' ')

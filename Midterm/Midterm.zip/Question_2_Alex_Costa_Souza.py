# Q2 - Output 100 lines with name using for loop
name = "Alex Costa Souza"

for i in range(1, 101):
    print(i, name)
